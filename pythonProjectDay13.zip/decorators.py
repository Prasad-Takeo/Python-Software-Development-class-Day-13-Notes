###Decorators
"""
Decorators are a very powerful and useful tool in python since it allows programmers to
modify the behaviour of function or class.

Decorators allows us to wrap another function in order to extend the behaviour of the wrapped
function without permanently modifying it
"""

# def shout(text):
#     return text.upper()
#
# def whisper(text):
#     return text.lower()
#
# def greet(a):
#     greeting = a("""Hi, I am created by a function passed as an argument""")
#     print(greeting)
#
# print(greet(shout)) #
# print(greet(whisper)) #

##in python, we can pass func as argument to the another func
#functions are first-class objects that means the functions in python
# can be user or passed as arguments

# def add(a,b):
#     return a+b
#
# a = add
# print(a(2,3))
#
# # return functions from another function
# def create_adder(x):  #create_adder(15) x= 15
#     def adder(y):
#         return x+y
#     return adder
#
# var1 = create_adder(15) #create_adder(15) x= 15
# print(var1(19)) #adder(19) y=19 -> 15+19 = 34
#
# def compare(x):
#     def greaterThan(y):
#         return x > y
#     return greaterThan
#
# compare_5 = compare(5)
# print(type(compare_5)) #output
# print(compare_5(7))

# def hello_decorator(func):
#
#     def inner1():
#         print("Hello, this is before function execution")
#         func()
#         print("Hello, this after function execution")
#     return inner1
#
# def function_to_be_used():
#     print("This is inside the function")
#
# var4 = hello_decorator(function_to_be_used)
# var4() #

#program to valid the input of sum

# def validate_input(func,a,b):
#     def validate():
#         if type(a) is str or type(b) is str:
#             return "No strings allowed"
#         else:
#             return func(a,b)
#     return validate
#
# def add(a,b):
#     return a+b
#
# var5 = validate_input(add,2,4)
# print(var5())
# var5 = validate_input(add,"sugumar",4)
# print(var5())

# use @ symbol for the decorator
import math
import time

def calculate_time(func):

    def inner1(*args,**kwargs):
        begin = time.time()
        func(*args,**kwargs)
        end = time.time()
        print("Total time taken in:",func.__name__,end-begin)
    return inner1

@calculate_time
def factorial(num):
    print(math.factorial(num))

factorial(100)


def decor1(func): #decor1(decor2(num)) 20 * 20
    def inner1():
        x = func() #20
        return x * x #20*20 = 400
    return inner1

def decor2(func):  #decor2(num)() -> 20
    def inner1():
        x = func() #10
        return 2 * x #20
    return inner1

#decor1(decor2(num)))
@decor1
@decor2
def num():
    return 10

print(num())

#write a decorator program to calcuate age from date of birth
# get dob -> return year of birth
# decorator -> return the age from the year
# @calculate_age -> caculate the age from the year
# @validate_dob -> condition is the year > 1990 and it should be numeric
# def get_dob():return '1992'
from datetime import datetime
def calculate_age(func):
    def inner1():
        b = func()
        #datetime.today().year - b
    return inner1

def validate_dob(func):
    def inner1():
        a = func()
        #validate if a is numeric return a else raise error
    return inner1

@calculate_age
@validate_dob
def get_dob():
    pass
    #input
    #return dob
